var globalUserActions = {
   
}
